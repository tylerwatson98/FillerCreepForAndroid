package es.softwareprocess.fillercreep;

public interface FView<M> {
    public void update(M model);
}
