package es.softwareprocess.fillercreep;

public interface AI {
    public FundamentalStuff evaluate(int playernumber, FillerCreep fillerCreep);
}
