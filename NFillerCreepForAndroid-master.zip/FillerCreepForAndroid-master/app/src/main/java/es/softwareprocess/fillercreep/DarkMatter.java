package es.softwareprocess.fillercreep;

public class DarkMatter extends FundamentalStuff {
    public FundamentalStuff copy() {
        return new DarkMatter();
    }

    public int intID() {
        return 2;
    }

    public String getName() {
        return "Dark Matter";
    }
}
